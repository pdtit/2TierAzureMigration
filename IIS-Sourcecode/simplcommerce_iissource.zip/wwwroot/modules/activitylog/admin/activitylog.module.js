﻿/*global angular*/
(function () {
    'use strict';

    angular
        .module('simplAdmin.activityLog', []);
})();